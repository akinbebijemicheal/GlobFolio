module.exports={
    secretOrKey:'oihdoefheoiefijff',
    PORT:'3000',
SECRET:'nomanlanddeepend-qwerty',
TOKEN:'oihdoefheoiefijff',
CSECRET:'foobarbaz1234567foobarbaz1234567',
NODE_ENV:'development'
};