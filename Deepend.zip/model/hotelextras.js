const Sequelize = require('sequelize');
const db = require('../config/config');
const {nanoid} = require('nanoid');
const Hotel = require('./hotel');
//const Cart = require('./cart')

const HotelExtra = db.define('hotelextra', {
    id: {
        type: Sequelize.STRING(10),
        autoincrement: false,
        allowNull: false,
        primaryKey: true,
        defaultValue: () => nanoid(10)
    },
    hotelId: {
        type: Sequelize.STRING(10),
        references:{ 
            model: 'hotels',
            key: 'id',
        }
    },
    available_room:{
        type: Sequelize.INTEGER
    },
    room:{
        type: Sequelize.TEXT
    },
    price: {
        type: Sequelize.TEXT
    }
    
});


HotelExtra.belongsTo(Hotel, {foreignKey: 'hotelId'})
Hotel.hasMany(HotelExtra, {foreignKey: 'hotelId'});

module.exports = HotelExtra;